package com.geanbrandao.gean.reiceitasapp.helper;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ValoresEstaticos {
    public static ObjectMapper mapper;

}
