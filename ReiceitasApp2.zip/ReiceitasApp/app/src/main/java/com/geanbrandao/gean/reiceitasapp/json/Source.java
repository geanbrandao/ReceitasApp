
package com.geanbrandao.gean.reiceitasapp.json;

public class Source {
	
	private String sourceDisplayName;
	private String sourceRecipeUrl;
	private String sourceSiteUrl;
	
	public String getSourceDisplayName() {
		return this.sourceDisplayName;
	}

	public void setSourceDisplayName(String sourceDisplayName) {
		this.sourceDisplayName = sourceDisplayName;
	}

	public String getSourceRecipeUrl() {
		return this.sourceRecipeUrl;
	}

	public void setSourceRecipeUrl(String sourceRecipeUrl) {
		this.sourceRecipeUrl = sourceRecipeUrl;
	}

	public String getSourceSiteUrl() {
		return this.sourceSiteUrl;
	}

	public void setSourceSiteUrl(String sourceSiteUrl) {
		this.sourceSiteUrl = sourceSiteUrl;
	}
}
